import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-contract-tab',
  templateUrl: './customer-contract-tab.component.html',
  styleUrls: ['./customer-contract-tab.component.scss']
})
export class CustomerContractTabComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
