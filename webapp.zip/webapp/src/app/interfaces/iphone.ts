export interface IPhone{
    phoneNumber: string;
    ddd: string;
    ddi: string;
}