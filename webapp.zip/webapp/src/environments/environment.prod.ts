export const environment = {
  production: true,
  CUSTOMER_MS: 'http://192.168.8.16:3506/api/v1/',
  message: '',
  protocol: 'http',
};
